<?php
    $SITE = "https://49plus.co.uk/udemy/";
?>